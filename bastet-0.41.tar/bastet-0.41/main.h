#ifndef _MAIN_H_
#define _MAIN_H_

extern char nightmare_mode;

extern void update_screen();
extern void cursor_vis(int vis);
extern void message(char *msg);

#endif /* _MAIN_H_ */
