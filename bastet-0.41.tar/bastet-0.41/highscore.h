/* highscore.h
   function prototypes for acces to highscore data */

#ifndef _HIGHSCORE_H_
#define _HIGHSCORE_H_

extern int check_highscores(unsigned int points);
extern int view_highscores();

#endif /* _HIGHSCORE_H_ */
